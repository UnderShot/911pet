/**
 * Created by undershot on 24.09.2016.
 */

(function($, window){


	if( $("#sprites").length ){
		var logo = $("a.main-logo-lg"),
			i = 0;


		logo.children("i.logo-lg-wave").each(function(i){
			var self = $(this);

			setTimeout(function () {
				self.addClass("animated");
			}, 200 * i);
		});
	}
	var tbl = $("table.dashboard-table");


	if( tbl.length ){

		tbl.each(function(){

			var rows = $(this).find("tr"),
				topTr = rows.filter(".tl_title"),
				bRows = rows.filter(":not(.tl_title)"),
				trObj = [];

			topTr.children("td").map(function(a,b){
				trObj.push(b.innerHTML);
			});

			bRows.each(function(){
				for( var i=1, colsLength = trObj.length; i<colsLength; i++ ){
					$(this).children("td").eq(i).prepend("<span class='table-mobile-label mobile-only'>" + trObj[i] + "</span>");
				}

			});

			//trObj.push();

			//console.log(topTr)

		});

	}

	var user = window.user;



	$("dialog").each(function(){
		dialogPolyfill.registerDialog(this);
	});

	$("button.dialog-close").on("click", function () {
		$(this).parents("dialog.mdl-dialog")[0].close();
	});



	if( user.id ){

		var userBehavior = {
			setProfile: function( data ){
				user.profile = data;

				$("#profile-avatar").attr("src", user.profile.photo_50);
				$("#side-name").html(user.profile.first_name + " " + user.profile.last_name );
			},
			setFriends: function( data ){

				user.vkFriends = data;

				/*user.profile = data;

				 $("#profile-avatar").attr("src", user.profile.photo_50);
				 $("#side-name").html(user.profile.first_name + " " + user.profile.last_name );*/
			},
			renderFriends: function(){
				var friends = '',
						frItems = user.vkFriends.items;
				for(var i = 0, friendsCount = user.vkFriends.count - 1; i < friendsCount; i++ ){
					if( frItems[i].deactivated ){
						continue;
					}

					friends += "<li class='vkFriends-list-item' data-vkId='http://vk.com/id" + frItems[i].id + "'>" + "<img src='" + frItems[i].photo_50 + "' class='vkFriends-list-avatar'>" + "<span class='vkFriends-list-name'>" + frItems[i].first_name + " " + frItems[i].last_name + "</span></li>";
				}
				return friends;
			}
		};

		$("#addNewUser").on("click", function () {
			var friendsWrap = $("#vkFriends");

			user.toInvite = [];
			//.html(user.id)
			friendsWrap.html(userBehavior.renderFriends());

			$("#newUserDialog")[0].showModal();
		});


		var req;

		req = "https://api.vk.com/method/users.get?user_ids=" + user.vkId + "&fields=photo_50,city&v=5.8";

		$.ajax({
			url : req,
			type : "GET",
			dataType : "jsonp",
			success: function(msg){
				userBehavior.setProfile(msg.response[0])
			}
		});

		// Get user friends
		req = "https://api.vk.com/method/friends.get?user_id=" + user.vkId + "&order=hints&fields=city,domain,photo_50&v=5.8";

		$.ajax({
			url : req,
			type : "GET",
			dataType : "jsonp",
			success: function(msg){
				userBehavior.setFriends(msg.response)
			}
		});



		$("body").on("click", "li.vkFriends-list-item", function(){
			var id = $(this).data("vkid");

			if( !$(this).hasClass("active") ){
				$(this).addClass("active");

				user.toInvite.push( id );
			} else{
				$(this).removeClass("active");

				user.toInvite.splice(user.toInvite.indexOf(id), 1);
			}


			return false;
		})
	}

	window.user = user;

}(jQuery, window));

